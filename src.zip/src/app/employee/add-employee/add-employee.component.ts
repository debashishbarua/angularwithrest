import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styles: [
  ]
})
export class AddEmployeeComponent implements OnInit {

  constructor(private employeeService: EmployeeService, private router: Router) { }

  ngOnInit(): void {
  }

  onSubmit(employeeForm) {
    console.log('on submit' + employeeForm.value);

    this.employeeService.addEmployee(employeeForm.value).subscribe(data => this.router.navigate(['/employees']));
  }
  onCancel() {
    this.router.navigate(['/employees'])
  }
}
