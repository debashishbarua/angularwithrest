import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../employee/employee';

const employeeUrl = "http://localhost:8080/employees";
@Injectable({
  providedIn: 'root'
})
export class DemoServiceService {

  constructor(private http: HttpClient) {
  }
  getAllEmployee(): Observable<Employee[]> {
    return this.http.get<Employee[]>(employeeUrl);
  }
}
