package com.cognizant.emp.controller;

import static org.hamcrest.CoreMatchers.any;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cognizant.emp.model.Employee;
import com.cognizant.emp.service.EmployeeService;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
class EmployeeControllerTest {
	
	/**
	 * At run time, Mockito will create a mock of EmployeeService
	 */
	@Mock
	private EmployeeService employeeSrvice;
	private Employee employee;
	private List<Employee> employees;

	/**
	 * Initilize the EmployeeController
	 */
	@InjectMocks
	private EmployeeController employeeController;

	/**
	 * Autowire the MockMvc
	 */
	@Autowired
	private MockMvc mockMvc;

	@BeforeEach
	void setUp() {
		employee = new Employee(10, "Akash", "Male", 25, 50000);
		mockMvc = MockMvcBuilders.standaloneSetup(employeeController).build();
	}

	@AfterEach
	void tearDown() {
		employee = null;
	}

	@Test
	void testGetEmployees() {
		fail("Not yet implemented");
	}

	@Test
	void testGetEmployeeById() {
		fail("Not yet implemented");
	}

	@Test
	void testAddEmployee() throws Exception{
	
	}

	@Test
	void testUpdateEmployee() {
		fail("Not yet implemented");
	}

	@Test
	void testDeleteEmployeeById() {
		fail("Not yet implemented");
	}

}
