package com.cognizant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDay88ApplicationTests {

	@Test
	void contextLoads() {
	}

}
