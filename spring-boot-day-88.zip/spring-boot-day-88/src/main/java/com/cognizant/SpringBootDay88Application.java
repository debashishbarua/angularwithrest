package com.cognizant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication
public class SpringBootDay88Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDay88Application.class, args);
	}
/*
	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurer() {		
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/employees/**")
				.allowedMethods("*")
				.allowedOrigins("http://localhost:4200");
			}
		};
	}*/
}
