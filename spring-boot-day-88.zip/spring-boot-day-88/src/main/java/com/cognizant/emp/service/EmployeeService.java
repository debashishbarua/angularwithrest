package com.cognizant.emp.service;

import java.util.List;

import com.cognizant.emp.model.Employee;

public interface EmployeeService {

	List<Employee> findEmployees();

	Employee addEmployee(Employee employee);

	String deleteEmployee(int id);

	Employee updateEmployee(int id, Employee employee);

	Employee findEmployeeById(int id);

}
