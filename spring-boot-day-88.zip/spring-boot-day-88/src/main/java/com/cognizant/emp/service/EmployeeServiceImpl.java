package com.cognizant.emp.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.emp.dao.EmployeeRepository;
import com.cognizant.emp.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public List<Employee> findEmployees() {
		return employeeRepository.findAll();
	}

	@Override
	public Employee addEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	@Override
	@Transactional
	public String deleteEmployee(int id) {
		Optional<Employee> optional=employeeRepository.findById(id);		
		if(optional.isPresent()) {
			employeeRepository.deleteById(id);
			return "Employee Deleted with id:" +id;
		}
		
		throw new RuntimeException();
	}

	@Override
	@Transactional
	public Employee updateEmployee(int id, Employee employee) {
	
		if (!employeeRepository.findById(id).isPresent()) {
			throw new RuntimeException("Employee " + id + " does not exists");
		}
		
		return employeeRepository.save(employee);
		
	}

	@Override
	public Employee findEmployeeById(int id) {
		Employee emp = employeeRepository.findById(id).get();
		return emp;
	}

}
